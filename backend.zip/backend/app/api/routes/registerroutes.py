from asyncio import run
import stat
from app.model.registeruser import community_creators, payments
from app.schemas.register import JoinCommunityRequest, JoinCommunityResponse
from app.schemas.register import SendMessageRequest, MessageResponse, CreatorResponse
from app.schemas.register import PaymentInitiateResponse, PaymentVerifyRequest, PaymentStatusResponse
from app.model.registeruser import chat_messages
from turtle import back
from datetime import datetime as dt

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.connections import get_db
from fastapi import File, UploadFile, Form
from app.model.registeruser import registeruser, forgotpasswordOTP,approved_posts,rejected_posts
from app.model.registeruser import posts, userprofile, post_reports, subscriptions, under_review_posts  
from app.schemas.register import RegisterUser, RegisterResponse, LoginResponse, LoginUser,ApprovedPostResponse,RejectedPostResponse
from app.schemas.register import forgotpassword, resetpassword, forgotpasswordResponse, resetpasswordResponse, userprofileResponse
from app.schemas.register import postsResponse, reportResponse, subscribeResponse, UnderReviewPost,UnderReviewResponse
from typing import List
import random as rnd
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from app.utils.security import create_access_token, verify_access_token
import os
import shutil
import uuid
import joblib
import sklearn
from app.services.llm_service import llm_check
from app.services.check_pending import check_and_trigger
router = APIRouter()
UPLOAD_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "uploads")
)
BASE_DIR = os.path.dirname(__file__)
MODEL_DIR = os.path.join(BASE_DIR, "..", "..", "ml_model")
print(MODEL_DIR)
model_path = os.path.abspath(os.path.join(MODEL_DIR, "lr_model.pkl"))
vector_path = os.path.abspath(os.path.join(MODEL_DIR, "vectorizer.pkl"))
selector_path = os.path.abspath(os.path.join(MODEL_DIR, "chi_selector.pkl"))
selector = joblib.load(selector_path)
vector = joblib.load(vector_path)
model = joblib.load(model_path)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
SECRET_KEY = "hackathon-secret-key"
ALGORITHM = "HS256"
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: int = payload.get("user_id")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(userprofile).filter(userprofile.user_id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user


@router.post("/register", response_model=RegisterResponse)
def register_user(user: RegisterUser, db: Session = Depends(get_db)):
    try:
        existing_user = db.query(registeruser).filter(
            (registeruser.email == user.email)
        ).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")

        new_user = registeruser(
            username=user.fullname,
            email=user.email,
            password=user.password
        )
        db.add(new_user)
        db.flush()

        new_profile = userprofile(
            user_id=new_user.id,
            about="",
            profile_pic=None
        )
        db.add(new_profile)
        db.commit()
        db.refresh(new_user)
        return {
            "message": "User registered successfully",
            "user_id": new_user.id,
            "fullname": new_user.username,
            "email": new_user.email
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/login", response_model=LoginResponse)
def login_user(user: LoginUser, db: Session = Depends(get_db)):
    existing_user = db.query(registeruser).filter(
        (registeruser.email == user.email) & (registeruser.password == user.password)
    ).first()
    if not existing_user:
        raise HTTPException(status_code=400, detail="Invalid email or password")
    access_token = create_access_token({"user_id": existing_user.id})
    return {"message": "Login successful", "access_token": access_token, "token_type": "bearer"}


@router.post("/forgotpassword", response_model=forgotpasswordResponse)
def forgotpassword(forgot: forgotpassword, db: Session = Depends(get_db)):
    user = db.query(registeruser).filter(registeruser.email == forgot.email).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid email")
    generated_otp = str(rnd.randint(100000, 999999))
    new_otp = forgotpasswordOTP(
        user_id=user.id,
        otp=generated_otp
    )
    db.add(new_otp)
    db.commit()
    db.refresh(new_otp)
    return {"otp": new_otp.otp}


@router.post("/resetpassword", response_model=resetpasswordResponse)
def resetpassword(reset: resetpassword, db: Session = Depends(get_db)):
    user = db.query(forgotpasswordOTP).filter(forgotpasswordOTP.otp == reset.otp).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid otp")
    passuser = db.query(registeruser).filter(registeruser.id == user.user_id).first()
    if not passuser:
        raise HTTPException(status_code=400, detail="Invalid id")
    passuser.password = reset.newpassword
    db.delete(user)
    db.commit()
    db.refresh(passuser)
    return {"msg": "Password Updated Successfully"}


@router.get("/loadprofile", response_model=userprofileResponse)
def profile(showprofile: userprofile = Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(registeruser).filter(registeruser.id == showprofile.user_id).first()
    subscriber_count = db.query(subscriptions).filter(
        subscriptions.subscribed_to_user_id == showprofile.user_id
    ).count()
    return {
        "username": user.username,
        "profile_picture": showprofile.profile_pic,
        "about": showprofile.about,
        "subscriber_count": subscriber_count
    }


@router.put("/update-profile", response_model=userprofileResponse)
async def update_profile(
    about: str = Form(...),
    profile_pic: UploadFile = File(None),
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        current_user.about = about

        if profile_pic:
            os.makedirs(UPLOAD_DIR, exist_ok=True)

            file_extension = os.path.splitext(profile_pic.filename)[1]
            filename = f"{uuid.uuid4()}{file_extension}"
            file_path = os.path.join(UPLOAD_DIR, filename)

            with open(file_path, "wb") as f:
                 f.write(await profile_pic.read())

            current_user.profile_pic = f"http://127.0.0.1:8000/uploads/{filename}"

        db.commit()
        db.refresh(current_user)

        user = db.query(registeruser).filter(registeruser.id == current_user.user_id).first()
        subscriber_count = db.query(subscriptions).filter(
            subscriptions.subscribed_to_user_id == current_user.user_id
        ).count()

        return {
            "username": user.username,
            "profile_picture": current_user.profile_pic,
            "about": current_user.about,
            "subscriber_count": subscriber_count
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/posts", response_model=postsResponse)
async def create_post(
    content: str = Form(...),
    media: UploadFile = File(None),
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        user = db.query(registeruser).filter(registeruser.id == current_user.user_id).first()

        vector_matrix = vector.transform([content])
        vector_matrix = selector.transform(vector_matrix)
        probs = model.predict_proba(vector_matrix)

        classes = model.classes_.tolist()
        edu_index = classes.index('educational')
        educational_prob = probs[0][edu_index]

        print("Educational probability:", educational_prob)

        new_post = posts(
            user_id=user.id,
            content=content,
            media_url=None,
            media_type=None
        )

        if media:
            os.makedirs(UPLOAD_DIR, exist_ok=True)

            file_extension = os.path.splitext(media.filename)[1]
            filename = f"post_{uuid.uuid4()}{file_extension}"
            file_path = os.path.join(UPLOAD_DIR, filename)

            contents = await media.read()
            with open(file_path, "wb") as f:
                f.write(contents)

            new_post.media_url = f"/uploads/{filename}"
            new_post.media_type = media.content_type

        db.add(new_post)
        db.commit()
        db.refresh(new_post)

        if educational_prob < 0.65:

            review_post = under_review_posts(
                user_id=user.id,
                content=content,
                media_url=new_post.media_url,
                media_type=new_post.media_type,
                confidence=str(educational_prob),
                post_id=new_post.id,
                status="pending"
            )

            db.add(review_post)
            db.commit()

        return {
            "id": new_post.id,
            "username": user.username,
            "profile_picture": current_user.profile_pic,
            "about": current_user.about or "",
            "content": new_post.content,
            "media_url": new_post.media_url,
            "report_count": new_post.report_count,
            "is_reported": False,
            "is_subscribed": False,
        }

    except HTTPException:
        raise

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))



@router.get("/posts", response_model=List[postsResponse])
async def get_posts(
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        all_posts = db.query(posts).order_by(posts.id.desc()).all()

        posts_data = []
        for post in all_posts:
            user = db.query(registeruser).filter(registeruser.id == post.user_id).first()
            profile = db.query(userprofile).filter(userprofile.user_id == user.id).first()

            already_reported = db.query(post_reports).filter(
                post_reports.post_id == post.id,
                post_reports.reporter_user_id == current_user.user_id
            ).first() is not None

            already_subscribed = db.query(subscriptions).filter(
                subscriptions.subscriber_user_id == current_user.user_id,
                subscriptions.subscribed_to_user_id == post.user_id
            ).first() is not None

            subscriber_count = db.query(subscriptions).filter(
                subscriptions.subscribed_to_user_id == post.user_id
            ).count()

            # Author is a creator if their profile status is "yes"
            author_is_creator = profile is not None and profile.status == "yes"

            # Subscribe button shows on any creator's post EXCEPT your own
            is_own_post = post.user_id == current_user.user_id
            can_subscribe = author_is_creator and not is_own_post

            # Check if current viewer has completed payment
            viewer_payment = db.query(payments).filter(
                payments.user_id == current_user.user_id,
                payments.status == "completed"
            ).first()
            viewer_has_paid = viewer_payment is not None

            posts_data.append({
                "id": post.id,
                "username": user.username,
                "profile_picture": profile.profile_pic if profile else None,
                "about": profile.about if profile else "",
                "content": post.content,
                "media_url": post.media_url,
                "report_count": post.report_count,
                "is_reported": already_reported,
                "is_subscribed": already_subscribed,
                "subscriber_count": subscriber_count,
                "can_subscribe": can_subscribe,
                "is_community_creator": author_is_creator,
                "is_own_post": is_own_post,
                "viewer_has_paid": viewer_has_paid,
            })

        return posts_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/posts/{post_id}/report", response_model=reportResponse)
async def report_post(
    post_id: int,
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        post = db.query(posts).filter(posts.id == post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")

        existing_report = db.query(post_reports).filter(
            post_reports.post_id == post_id,
            post_reports.reporter_user_id == current_user.user_id
        ).first()

        if existing_report:
            raise HTTPException(status_code=400, detail="You have already reported this post")

        new_report = post_reports(
            post_id=post_id,
            reporter_user_id=current_user.user_id
        )
        db.add(new_report)

        post.report_count = (post.report_count or 0) + 1
        db.commit()

        if post.report_count >= 3:
            if post.media_url:
                media_filename = post.media_url.split("/uploads/")[-1]
                media_file_path = os.path.join(UPLOAD_DIR, media_filename)
                if os.path.exists(media_file_path):
                    os.remove(media_file_path)
            db.delete(post)
            db.commit()
            return {"message": "Post removed due to multiple reports", "report_count": 3, "post_removed": True}

        db.refresh(post)
        return {"message": "Post reported successfully", "report_count": post.report_count, "post_removed": False}

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/posts/{post_id}/subscribe", response_model=subscribeResponse)
async def toggle_subscribe(
    post_id: int,
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        post = db.query(posts).filter(posts.id == post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")

        # Block self-subscription
        if post.user_id == current_user.user_id:
            raise HTTPException(status_code=400, detail="You cannot subscribe to your own posts")

        # Check the post author is actually a creator
        author_profile = db.query(userprofile).filter(userprofile.user_id == post.user_id).first()
        if not author_profile or author_profile.status != "yes":
            raise HTTPException(status_code=400, detail="This user is not a community creator")

        # Check viewer has completed payment before subscribing
        viewer_payment = db.query(payments).filter(
            payments.user_id == current_user.user_id,
            payments.status == "completed"
        ).first()
        if not viewer_payment:
            raise HTTPException(status_code=402, detail="Payment required to subscribe")

        existing_sub = db.query(subscriptions).filter(
            subscriptions.subscriber_user_id == current_user.user_id,
            subscriptions.subscribed_to_user_id == post.user_id
        ).first()

        if existing_sub:
            db.delete(existing_sub)
            db.commit()
            return {"message": "Unsubscribed successfully", "is_subscribed": False}
        else:
            new_sub = subscriptions(
                subscriber_user_id=current_user.user_id,
                subscribed_to_user_id=post.user_id
            )
            db.add(new_sub)
            db.commit()
            return {"message": "Subscribed successfully", "is_subscribed": True}

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    
@router.post("/llm-processing")
async def llm_processing(db: Session = Depends(get_db)):

    try:
        pending_posts = db.query(under_review_posts).filter(
            under_review_posts.status == "pending"
        ).all()
        processed_posts = []
        for post in pending_posts:
            content = post.content
            result = llm_check(content)

            if result == "educational":

                approved_entry = approved_posts(
                    post_id=post.post_id
                )

                db.add(approved_entry)
                post.status = "approved"

            else:
                rejected_entry = rejected_posts(
                    post_id=post.post_id,
                    reason="LLM detected non educational content"
                )

                db.add(rejected_entry)
                post.status = "rejected"

            processed_posts.append(post.post_id)

        db.commit()
        return {
            "message": "LLM processing completed",
            "processed_posts": processed_posts
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )    

@router.post("/join-community", response_model=JoinCommunityResponse)
async def join_community(
    data: JoinCommunityRequest,
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        existing = db.query(community_creators).filter(
            community_creators.creator_id == current_user.id
        ).first()

        if existing:
            return {"message": "Already a community member", "status": "yes"}

        new_creator = community_creators(
            creator_id=current_user.id,
            name=data.name,
            upi_id=data.upi_id,
            subscription_fee="0.00"
        )
        db.add(new_creator)

        current_user.status = "yes"
        db.commit()

        return {"message": "Successfully joined the community!", "status": "yes"}

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/community-status", response_model=JoinCommunityResponse)
async def community_status(
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return {"message": "Status fetched", "status": current_user.status or "no"}
        

@router.get("/check_pending")
async def check_pending(db: Session = Depends(get_db)):
    try:
        result = check_and_trigger(db)
        return result

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )      



# ---------------------------------------------------
# GET SUBSCRIBED CREATORS (for Community page)
# ---------------------------------------------------

@router.get("/community/creators", response_model=List[CreatorResponse])
async def get_subscribed_creators(
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns all users that the current user is subscribed to
    AND who are community creators (joined community).
    """
    try:
        subs = db.query(subscriptions).filter(
            subscriptions.subscriber_user_id == current_user.user_id
        ).all()

        creators_list = []
        for sub in subs:
            target_profile = db.query(userprofile).filter(
                userprofile.user_id == sub.subscribed_to_user_id
            ).first()

            if not target_profile or target_profile.status != "yes":
                continue

            target_user = db.query(registeruser).filter(
                registeruser.id == sub.subscribed_to_user_id
            ).first()

            if target_user:
                creators_list.append({
                    "user_id": target_user.id,
                    "username": target_user.username,
                    "about": target_profile.about,
                    "profile_pic": target_profile.profile_pic,
                })

        return creators_list

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------
# GET MY SUBSCRIBERS (for creator's "My Subscribers" page)
# ---------------------------------------------------

@router.get("/community/subscribers", response_model=List[CreatorResponse])
async def get_my_subscribers(
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns all users who have subscribed to the current creator,
    along with whether they have sent any unread messages.
    Only accessible by community creators.
    """
    try:
        subs = db.query(subscriptions).filter(
            subscriptions.subscribed_to_user_id == current_user.user_id
        ).all()

        subscribers_list = []
        for sub in subs:
            sub_profile = db.query(userprofile).filter(
                userprofile.user_id == sub.subscriber_user_id
            ).first()

            sub_user = db.query(registeruser).filter(
                registeruser.id == sub.subscriber_user_id
            ).first()

            if not sub_user:
                continue

            has_message = db.query(chat_messages).filter(
                chat_messages.sender_user_id == sub.subscriber_user_id,
                chat_messages.receiver_user_id == current_user.user_id
            ).first() is not None

            subscribers_list.append({
                "user_id": sub_user.id,
                "username": sub_user.username,
                "about": sub_profile.about if sub_profile else None,
                "profile_pic": sub_profile.profile_pic if sub_profile else None,
                "has_message": has_message,
            })

        return subscribers_list

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------
# GET CHAT HISTORY
# ---------------------------------------------------

@router.get("/chat/{other_user_id}")
async def get_chat_history(
    other_user_id: int,
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        other_user = db.query(registeruser).filter(
            registeruser.id == other_user_id
        ).first()
        if not other_user:
            raise HTTPException(status_code=404, detail="User not found")

        other_profile = db.query(userprofile).filter(
            userprofile.user_id == other_user_id
        ).first()

        is_subscribed = db.query(subscriptions).filter(
            subscriptions.subscriber_user_id == current_user.user_id,
            subscriptions.subscribed_to_user_id == other_user_id
        ).first()

        creator_subscribed_to_me = db.query(subscriptions).filter(
            subscriptions.subscriber_user_id == other_user_id,
            subscriptions.subscribed_to_user_id == current_user.user_id
        ).first()

        other_is_creator = other_profile and other_profile.status == "yes"
        current_is_creator = current_user.status == "yes"

        allowed = (is_subscribed and other_is_creator) or \
                  (creator_subscribed_to_me and current_is_creator) or \
                  (other_is_creator and current_is_creator)

        if not allowed:
            raise HTTPException(
                status_code=403,
                detail="You must be subscribed to this creator to chat."
            )

        messages = db.query(chat_messages).filter(
            (
                (chat_messages.sender_user_id == current_user.user_id) &
                (chat_messages.receiver_user_id == other_user_id)
            ) | (
                (chat_messages.sender_user_id == other_user_id) &
                (chat_messages.receiver_user_id == current_user.user_id)
            )
        ).order_by(chat_messages.timestamp.asc()).all()

        messages_data = [
            {
                "id": msg.id,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat(),
                "is_mine": msg.sender_user_id == current_user.user_id,
                "sender_username": msg.sender.username,
            }
            for msg in messages
        ]

        return {
            "other_user": {
                "user_id": other_user.id,
                "username": other_user.username,
                "profile_pic": other_profile.profile_pic if other_profile else None,
            },
            "messages": messages_data,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------
# SEND MESSAGE
# ---------------------------------------------------

@router.post("/chat/{other_user_id}")
async def send_message(
    other_user_id: int,
    body: SendMessageRequest,
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        if not body.content.strip():
            raise HTTPException(status_code=400, detail="Message cannot be empty")

        other_user = db.query(registeruser).filter(
            registeruser.id == other_user_id
        ).first()
        if not other_user:
            raise HTTPException(status_code=404, detail="User not found")

        other_profile = db.query(userprofile).filter(
            userprofile.user_id == other_user_id
        ).first()

        is_subscribed = db.query(subscriptions).filter(
            subscriptions.subscriber_user_id == current_user.user_id,
            subscriptions.subscribed_to_user_id == other_user_id
        ).first()

        creator_subscribed_to_me = db.query(subscriptions).filter(
            subscriptions.subscriber_user_id == other_user_id,
            subscriptions.subscribed_to_user_id == current_user.user_id
        ).first()

        other_is_creator = other_profile and other_profile.status == "yes"
        current_is_creator = current_user.status == "yes"

        allowed = (is_subscribed and other_is_creator) or \
                  (creator_subscribed_to_me and current_is_creator) or \
                  (other_is_creator and current_is_creator)

        if not allowed:
            raise HTTPException(
                status_code=403,
                detail="You must be subscribed to this creator to chat."
            )

        new_msg = chat_messages(
            sender_user_id=current_user.user_id,
            receiver_user_id=other_user_id,
            content=body.content.strip(),
        )
        db.add(new_msg)
        db.commit()
        db.refresh(new_msg)

        sender_user = db.query(registeruser).filter(
            registeruser.id == current_user.user_id
        ).first()

        return {
            "id": new_msg.id,
            "content": new_msg.content,
            "timestamp": new_msg.timestamp.isoformat(),
            "is_mine": True,
            "sender_username": sender_user.username,
        }

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ---------------------------------------------------
# PAYMENT ENDPOINTS
# ---------------------------------------------------

PLATFORM_UPI_ID = "trickit@upi"
PAYMENT_AMOUNT = "99.00"

@router.post("/payment/initiate", response_model=PaymentInitiateResponse)
async def initiate_payment(
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        existing = db.query(payments).filter(
            payments.user_id == current_user.user_id
        ).first()

        if existing and existing.status == "completed":
            return {
                "payment_id": existing.id,
                "amount": existing.amount,
                "upi_id": PLATFORM_UPI_ID,
                "message": "Payment already completed",
                "status": "completed",
            }

        if existing:
            return {
                "payment_id": existing.id,
                "amount": existing.amount,
                "upi_id": PLATFORM_UPI_ID,
                "message": "Payment pending. Enter your UPI transaction reference to verify.",
                "status": "pending",
            }

        new_payment = payments(
            user_id=current_user.user_id,
            amount=PAYMENT_AMOUNT,
            status="pending",
        )
        db.add(new_payment)
        db.commit()
        db.refresh(new_payment)

        return {
            "payment_id": new_payment.id,
            "amount": new_payment.amount,
            "upi_id": PLATFORM_UPI_ID,
            "message": f"Pay ₹{PAYMENT_AMOUNT} to {PLATFORM_UPI_ID} and enter your UPI reference below.",
            "status": "pending",
        }

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/payment/verify", response_model=PaymentStatusResponse)
async def verify_payment(
    body: PaymentVerifyRequest,
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        payment = db.query(payments).filter(
            payments.id == body.payment_id,
            payments.user_id == current_user.user_id
        ).first()

        if not payment:
            raise HTTPException(status_code=404, detail="Payment record not found")

        if payment.status == "completed":
            return {"has_paid": True, "status": "completed", "payment_id": payment.id}

        if not body.upi_ref or not body.upi_ref.strip():
            raise HTTPException(status_code=400, detail="UPI transaction reference is required")

        payment.upi_ref = body.upi_ref.strip()
        payment.status = "completed"
        payment.completed_at = dt.utcnow()
        db.commit()

        return {"has_paid": True, "status": "completed", "payment_id": payment.id}

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/payment/status", response_model=PaymentStatusResponse)
async def payment_status(
    current_user: userprofile = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        payment = db.query(payments).filter(
            payments.user_id == current_user.user_id
        ).first()

        if not payment:
            return {"has_paid": False, "status": "not_initiated", "payment_id": None}

        return {
            "has_paid": payment.status == "completed",
            "status": payment.status,
            "payment_id": payment.id,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))